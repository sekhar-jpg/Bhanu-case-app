const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb+srv://bhanuhomeopathy:sekhar123456@cluster0.wm2pxqs.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const Case = require('./models/Case');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.post('/add-case', async (req, res) => {
  const newCase = new Case(req.body);
  await newCase.save();
  res.redirect('/');
});

app.post('/delete-case', async (req, res) => {
  await Case.findByIdAndDelete(req.body.id);
  res.redirect('/');
});

app.get('/reminders', async (req, res) => {
  const fifteenDaysAgo = new Date();
  fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);
  const dueFollowUps = await Case.find({ date: { $lte: fifteenDaysAgo } });
  res.json(dueFollowUps);
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));