const mongoose = require('mongoose');

const CaseSchema = new mongoose.Schema({
  name: String,
  age: Number,
  phone: String,
  date: {
    type: Date,
    default: Date.now
  },
  notes: String
});

module.exports = mongoose.model('Case', CaseSchema);